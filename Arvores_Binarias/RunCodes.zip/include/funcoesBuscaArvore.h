#ifndef FUNCOESARVOREBUSCA_H
#define FUNCOESARVOREBUSCA_H

#include "funcoesAuxiliares.h"

//////////////////////////////////////////////////////// FUNCOES DE BUSCA

NoPos BuscarNoArvore(char *arquivo, long int chave);

#endif

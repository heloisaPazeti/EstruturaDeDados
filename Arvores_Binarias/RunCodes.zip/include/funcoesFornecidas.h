#ifndef FUNCOEFORNECIDADES_H
#define FUNCOEFORNECIDADES_H

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

void binarioNaTela(char *nomeArquivoBinario);
void scan_quote_string(char *str);
long converteNome(char* str);

#endif
